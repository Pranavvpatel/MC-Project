package com.example.authapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
