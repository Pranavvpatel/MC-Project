import 'package:flutter/material.dart';
import 'login_page.dart';
import 'api_service.dart';
import 'expense.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // Initialize a map to store user credentials
  final Map<String, String> users = {};

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Expnse_App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: LoginPage(users: users), // Pass the users map to LoginPage
    );
  }
}
