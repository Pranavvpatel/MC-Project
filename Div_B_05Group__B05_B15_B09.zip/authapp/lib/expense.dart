// lib/expense.dart

class Expense {
  int _id; // Make this a private field
  String name;
  double amount;

  // Constructor
  Expense({required int id, required this.name, required this.amount}) : _id = id;

  // Getter for id
  int get id => _id;

  // Optional: Method to convert JSON to Expense object
  factory Expense.fromJson(Map<String, dynamic> json) {
    return Expense(
      id: json['id'],
      name: json['name'],
      amount: json['amount'].toDouble(),
    );
  }

  // Optional: Method to convert Expense object to JSON
  Map<String, dynamic> toJson() {
    return {
      'id': _id,
      'name': name,
      'amount': amount,
    };
  }

  // Setter for id (if you want to allow changing the ID)
  set id(int value) {
    _id = value;
  }
}
