import 'dart:convert';
import 'dart:io';
import 'expense.dart';

class ApiService {
  List<Expense> _expenses = []; // Local list to store expenses

  Future<List<Expense>> fetchExpenses() async {
    await Future.delayed(Duration(milliseconds: 50)); // Simulating network delay
    return _expenses; // Return the current list of expenses
  }

  Future<void> addExpense(Expense expense) async {
    await Future.delayed(Duration(milliseconds: 50)); // Simulating network delay
    expense.id = _expenses.length + 1; // Assign an ID
    _expenses.add(expense); // Add to the local list
  }

  Future<void> deleteExpense(int id) async {
    await Future.delayed(Duration(milliseconds: 50)); // Simulating network delay
    _expenses.removeWhere((expense) => expense.id == id); // Remove expense by ID
  }
}


