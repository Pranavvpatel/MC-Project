import 'package:flutter/material.dart';
import 'api_service.dart';
import 'expense.dart';
import 'expense_detail_screen.dart';
import 'login_page.dart'; // Import your login page

class ExpenseListScreen extends StatefulWidget {
  final VoidCallback onLogout; // Add a callback for logout

  ExpenseListScreen({required this.onLogout}); // Accept the logout callback

  @override
  _ExpenseListScreenState createState() => _ExpenseListScreenState();
}

class _ExpenseListScreenState extends State<ExpenseListScreen> {
  final ApiService apiService = ApiService();
  List<Expense> expenses = [];

  @override
  void initState() {
    super.initState();
    _loadExpenses();
  }

  void _addExpense(String name, double amount) async {
    if (name.isNotEmpty && amount > 0) {
      try {
        final newExpense = Expense(id: 0, name: name, amount: amount);
        await apiService.addExpense(newExpense);
        await _loadExpenses(); // Reload the list after adding
      } catch (e) {
        print('Error adding expense: $e');
      }
    } else {
      print('Invalid expense data: name: $name, amount: $amount');
    }
  }

  Future<void> _loadExpenses() async {
    try {
      expenses = await apiService.fetchExpenses();
      setState(() {});
    } catch (e) {
      print('Error loading expenses: $e');
    }
  }

  void _deleteExpense(int id) async {
    try {
      await apiService.deleteExpense(id);
      await _loadExpenses(); // Reload the expenses after deletion
    } catch (e) {
      print('Error deleting expense: $e');
    }
  }

  void _showAddExpenseDialog() {
    final TextEditingController nameController = TextEditingController();
    final TextEditingController amountController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Add Expense'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                decoration: InputDecoration(labelText: 'Expense Name'),
              ),
              TextField(
                controller: amountController,
                decoration: InputDecoration(labelText: 'Amount'),
                keyboardType: TextInputType.number,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                final name = nameController.text;
                final amount = double.tryParse(amountController.text) ?? 0;
                _addExpense(name, amount);
                Navigator.of(context).pop();
              },
              child: Text('Add'),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('Cancel'),
            ),
          ],
        );
      },
    );
  }

  void _viewExpense(Expense expense) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => ExpenseDetailScreen(expense: expense),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Expenses'),
        actions: [
          IconButton(
            icon: Icon(Icons.logout), // Logout icon
            onPressed: () {
              widget.onLogout(); // Call the logout callback
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Successfully logged out!'), // Success message
                ),
              );
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (context) => LoginPage(users: {},)), // Navigate to the login page
                    (route) => false, // Remove all previous routes
              );
            },
          ),
        ],
      ),
      body: expenses.isEmpty
          ? Center(child: Text('No expenses found.'))
          : ListView.builder(
        itemCount: expenses.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(expenses[index].name),
            subtitle: Text('\₹${expenses[index].amount.toStringAsFixed(2)}'),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: Icon(Icons.visibility), // Eye icon for view
                  onPressed: () => _viewExpense(expenses[index]),
                ),
                IconButton(
                  icon: Icon(Icons.delete),
                  onPressed: () => _deleteExpense(expenses[index].id),
                ),
              ],
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddExpenseDialog,
        child: Icon(Icons.add),
      ),
    );
  }
}
